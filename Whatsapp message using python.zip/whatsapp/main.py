import pywhatkit as kit

kit.sendwhatmsg("+919*********", "I love codingwithsagar!", 13, 10)